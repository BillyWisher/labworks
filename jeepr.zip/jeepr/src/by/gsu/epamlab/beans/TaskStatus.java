package by.gsu.epamlab.beans;

/**
 * Task statuses
 */
public enum TaskStatus {
    ACTIVE, FIXED, DELETED;
}
