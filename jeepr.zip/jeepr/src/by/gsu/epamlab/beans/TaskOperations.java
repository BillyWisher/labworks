package by.gsu.epamlab.beans;

/**
 * Operations for tasks
 */
public enum TaskOperations {
	CREATE, DELETE, FIX, HARDDELETE, RESTORE, UNFIX;
}
